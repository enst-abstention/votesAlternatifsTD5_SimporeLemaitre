# votes-alternatifs
Projet Informatique U.E 2.4

Pour lancer l'IHM, exécuter le fichier Codes/main.py.
Il faut d'abord créer une élection avec la base de données "electionTest" qui est la seule disponible.
Ensuite vous pouvez voter avec des électeurs présents dans la la table électeur de BDD.
