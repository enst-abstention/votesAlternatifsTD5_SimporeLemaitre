# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'ui\jugMajBulletin.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Dialog(object):
    def setupUi(self, Dialog):
        Dialog.setObjectName("Dialog")
        Dialog.resize(639, 824)
        self.widget = QtWidgets.QWidget(Dialog)
        self.widget.setGeometry(QtCore.QRect(0, 0, 640, 825))
        self.widget.setObjectName("widget")
        self.label_5 = QtWidgets.QLabel(self.widget)
        self.label_5.setGeometry(QtCore.QRect(470, 430, 221, 20))
        self.label_5.setStyleSheet("font: 12pt \"MS Shell Dlg 2\";\n"
"color: rgb(255, 0, 0);\n"
"color: rgb(255, 0, 0);")
        self.label_5.setText("")
        self.label_5.setObjectName("label_5")
        self.label = QtWidgets.QLabel(self.widget)
        self.label.setGeometry(QtCore.QRect(60, 100, 451, 41))
        self.label.setStyleSheet("color: rgb(0, 0, 0);\n"
"alternate-background-color: rgb(93, 93, 93);\n"
"background-color: rgb(113, 113, 113);\n"
"font: 8pt \"Kristen ITC\";\n"
"font: 24pt \"Kristen ITC\";\n"
"")
        self.label.setObjectName("label")
        self.label_3 = QtWidgets.QLabel(self.widget)
        self.label_3.setGeometry(QtCore.QRect(130, 140, 271, 31))
        self.label_3.setStyleSheet("color: rgb(0, 85, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"font: 8pt \"Kristen ITC\";")
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.widget)
        self.label_4.setGeometry(QtCore.QRect(20, 190, 261, 51))
        self.label_4.setStyleSheet("color: rgb(0, 85, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.label_4.setObjectName("label_4")
        self.comboBoxC1 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC1.setGeometry(QtCore.QRect(72, 271, 81, 41))
        self.comboBoxC1.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);\n"
"")
        self.comboBoxC1.setObjectName("comboBoxC1")
        self.comboBoxC5 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC5.setGeometry(QtCore.QRect(250, 270, 91, 41))
        self.comboBoxC5.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC5.setObjectName("comboBoxC5")
        self.comboBoxC9 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC9.setGeometry(QtCore.QRect(460, 270, 101, 41))
        self.comboBoxC9.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC9.setObjectName("comboBoxC9")
        self.comboBoxC2 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC2.setGeometry(QtCore.QRect(70, 360, 81, 41))
        self.comboBoxC2.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC2.setObjectName("comboBoxC2")
        self.comboBoxC6 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC6.setGeometry(QtCore.QRect(250, 360, 91, 41))
        self.comboBoxC6.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC6.setObjectName("comboBoxC6")
        self.comboBoxC10 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC10.setGeometry(QtCore.QRect(460, 350, 101, 41))
        self.comboBoxC10.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC10.setObjectName("comboBoxC10")
        self.comboBoxC3 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC3.setGeometry(QtCore.QRect(70, 450, 81, 41))
        self.comboBoxC3.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC3.setObjectName("comboBoxC3")
        self.comboBoxC7 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC7.setGeometry(QtCore.QRect(250, 450, 101, 41))
        self.comboBoxC7.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC7.setObjectName("comboBoxC7")
        self.comboBoxC11 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC11.setGeometry(QtCore.QRect(460, 440, 101, 41))
        self.comboBoxC11.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC11.setObjectName("comboBoxC11")
        self.comboBoxC4 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC4.setGeometry(QtCore.QRect(70, 540, 81, 41))
        self.comboBoxC4.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC4.setObjectName("comboBoxC4")
        self.comboBoxC8 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC8.setGeometry(QtCore.QRect(250, 540, 101, 41))
        self.comboBoxC8.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC8.setObjectName("comboBoxC8")
        self.comboBoxC12 = QtWidgets.QComboBox(self.widget)
        self.comboBoxC12.setGeometry(QtCore.QRect(460, 540, 91, 41))
        self.comboBoxC12.setStyleSheet("background-color: rgb(0, 85, 255);\n"
"background-color: rgb(0, 0, 0);\n"
"background-color: rgb(52, 86, 127);")
        self.comboBoxC12.setObjectName("comboBoxC12")
        self.labelC1 = QtWidgets.QLabel(self.widget)
        self.labelC1.setGeometry(QtCore.QRect(4, 280, 51, 20))
        self.labelC1.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.labelC1.setObjectName("labelC1")
        self.labelC2 = QtWidgets.QLabel(self.widget)
        self.labelC2.setGeometry(QtCore.QRect(0, 370, 55, 16))
        self.labelC2.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"\n"
"")
        self.labelC2.setObjectName("labelC2")
        self.labelC3 = QtWidgets.QLabel(self.widget)
        self.labelC3.setGeometry(QtCore.QRect(0, 460, 55, 16))
        self.labelC3.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.labelC3.setObjectName("labelC3")
        self.labelC4 = QtWidgets.QLabel(self.widget)
        self.labelC4.setGeometry(QtCore.QRect(0, 550, 55, 16))
        self.labelC4.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"\n"
"")
        self.labelC4.setObjectName("labelC4")
        self.labelC5 = QtWidgets.QLabel(self.widget)
        self.labelC5.setGeometry(QtCore.QRect(190, 280, 55, 16))
        self.labelC5.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.labelC5.setObjectName("labelC5")
        self.labelC6 = QtWidgets.QLabel(self.widget)
        self.labelC6.setGeometry(QtCore.QRect(190, 370, 55, 16))
        self.labelC6.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"\n"
"")
        self.labelC6.setObjectName("labelC6")
        self.labelC7 = QtWidgets.QLabel(self.widget)
        self.labelC7.setGeometry(QtCore.QRect(180, 460, 55, 16))
        self.labelC7.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.labelC7.setObjectName("labelC7")
        self.labelC8 = QtWidgets.QLabel(self.widget)
        self.labelC8.setGeometry(QtCore.QRect(180, 550, 55, 16))
        self.labelC8.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"\n"
"")
        self.labelC8.setObjectName("labelC8")
        self.labelC9 = QtWidgets.QLabel(self.widget)
        self.labelC9.setGeometry(QtCore.QRect(390, 280, 55, 16))
        self.labelC9.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.labelC9.setObjectName("labelC9")
        self.labelC10 = QtWidgets.QLabel(self.widget)
        self.labelC10.setGeometry(QtCore.QRect(390, 360, 55, 16))
        self.labelC10.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"\n"
"")
        self.labelC10.setObjectName("labelC10")
        self.labelC11 = QtWidgets.QLabel(self.widget)
        self.labelC11.setGeometry(QtCore.QRect(390, 450, 55, 16))
        self.labelC11.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.labelC11.setObjectName("labelC11")
        self.labelC12 = QtWidgets.QLabel(self.widget)
        self.labelC12.setGeometry(QtCore.QRect(400, 550, 55, 16))
        self.labelC12.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(170, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"\n"
"")
        self.labelC12.setObjectName("labelC12")
        self.buttonBack = QtWidgets.QPushButton(self.widget)
        self.buttonBack.setGeometry(QtCore.QRect(10, 10, 93, 28))
        self.buttonBack.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"color: rgb(0, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.buttonBack.setObjectName("buttonBack")
        self.buttonAVoter = QtWidgets.QPushButton(self.widget)
        self.buttonAVoter.setGeometry(QtCore.QRect(230, 660, 301, 28))
        self.buttonAVoter.setStyleSheet("font: 8pt \"Kristen ITC\";\n"
"font: 75 8pt \"MS Shell Dlg 2\";\n"
"color: rgb(0, 0, 0);\n"
"font: 8pt \"Kristen ITC\";\n"
"")
        self.buttonAVoter.setObjectName("buttonAVoter")

        self.retranslateUi(Dialog)
        QtCore.QMetaObject.connectSlotsByName(Dialog)

    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
        self.label.setText(_translate("Dialog", "Election Présidentielle"))
        self.label_3.setText(_translate("Dialog", "Attribuez une mention a chaque candidat"))
        self.label_4.setText(_translate("Dialog", "Mode de scrutin : Jugement Majoritaire"))
        self.labelC1.setText(_translate("Dialog", "        c1"))
        self.labelC2.setText(_translate("Dialog", "       c2"))
        self.labelC3.setText(_translate("Dialog", "        c3"))
        self.labelC4.setText(_translate("Dialog", "       c4"))
        self.labelC5.setText(_translate("Dialog", "       c5"))
        self.labelC6.setText(_translate("Dialog", "       c6"))
        self.labelC7.setText(_translate("Dialog", "        c7"))
        self.labelC8.setText(_translate("Dialog", "        c8"))
        self.labelC9.setText(_translate("Dialog", "       c9"))
        self.labelC10.setText(_translate("Dialog", "       c10"))
        self.labelC11.setText(_translate("Dialog", "        c11"))
        self.labelC12.setText(_translate("Dialog", "         c12"))
        self.buttonBack.setText(_translate("Dialog", "Retour"))
        self.buttonAVoter.setText(_translate("Dialog", "DEPOSER MON BULLETIN DANS L\'URNE"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    Dialog = QtWidgets.QDialog()
    ui = Ui_Dialog()
    ui.setupUi(Dialog)
    Dialog.show()
    sys.exit(app.exec_())
